"""§2.5 — BA candidate, BA cặp, hai kiểm định ghép cặp trên từng cặp.

Module này KHÔNG cài lại phép tính nào. `paired_bootstrap`, `permutation_paired`,
`cohen_dz`, `holm`, `align_blocks` đều import nguyên văn từ `src/stats_ab.py` —
đường đã cho ra bảng §2.3 và đã có selftest đối chiếu với scipy. Thứ duy nhất
đổi ở đây là **họ hiệu chỉnh Holm**, và đó đúng là thứ k = 3 làm đổi.

── VÌ SAO KHÔNG GỌI THẲNG `stats_ab.compare_all` BA LẦN ────────────────────
`compare_all` chạy Holm TRONG MỘT CẶP, trên các metric. Gọi nó ba lần rồi
hiệu chỉnh thêm một lần nữa là hiệu chỉnh HAI LẦN: mỗi p đã bị phạt theo số
metric, rồi bị phạt lại theo số cặp, và bảng kết quả trở nên bảo thủ theo một
cách không ai khai báo.

Ở §2.5 câu hỏi là "trên metric NÀY, ba cặp cái nào khác nhau" — nên họ Holm
đúng là **ba cặp trong một metric**, chạy riêng cho từng metric và riêng cho
từng kiểm định (permutation và bootstrap là hai họ, vì hai p của cùng một cặp
trả lời cùng một câu hỏi trên cùng dữ liệu).

`stats.adjust_scope` khai điều đó ra thay vì để nó là một quy ước ngầm:
    pairs   — Holm trên 3 cặp, trong từng metric   (mặc định của §2.5)
    metrics — Holm trên các metric, trong từng cặp (hành vi của §2.3)
    all     — Holm trên toàn bộ 3 × n_metric p

── DẤU CỦA HIỆU SỐ ─────────────────────────────────────────────────────────
Mọi hiệu số đọc là `B − A` với (A, B) là cặp đã sắp. `stats.reference` đẩy
candidate tham chiếu về phía A, nên với `reference: my_gemma` thì cột
`mean_diff` dương nghĩa là **baseline hơn** My Gemma. Đó là một quy ước, và nó
được in thẳng vào REPORT.md để không ai phải đoán chiều.
"""
from __future__ import annotations

from itertools import combinations

import numpy as np
import pandas as pd

from .stats_ab import (align_blocks, cohen_dz, holm, materiality_warning,
                       paired_bootstrap, permutation_paired,
                       resolution_warning)

__all__ = ["align_blocks", "pair_list", "compare_pairs", "summary_lines",
           "resolution_warning"]


def pair_list(arm_ids: list[str], mode: str = "all",
              reference: str | None = None) -> list[tuple[str, str]]:
    """Các cặp cần kiểm, đã sắp sao cho `reference` luôn đứng ở vị trí A.

    `mode = vs_reference` bỏ cặp không chứa tham chiếu. Đó là một thiết kế hợp
    lệ (hai câu hỏi thay vì ba) nhưng nó KHÔNG phải mặc định của §2.5: cặp
    R2Gen–AdaAtt là mốc để biết hai baseline có tách nhau trên tập này không,
    và thiếu nó thì một bảng "My Gemma hơn cả hai" không nói được là hơn nhiều
    hay chỉ hơn đúng cái khoảng cách vốn có giữa hai baseline.
    """
    ids = list(arm_ids)
    mode = str(mode or "all").lower()
    if mode not in ("all", "vs_reference"):
        raise ValueError(
            f"stats.pairs = {mode!r}; hợp lệ: 'all' | 'vs_reference'.")
    if reference is not None and reference not in ids:
        raise ValueError(
            f"stats.reference = {reference!r} không nằm trong các candidate có "
            f"điểm ({ids}). Tham chiếu quyết định DẤU của mọi hiệu số, nên một "
            f"giá trị sai ở đây làm cả bảng đọc ngược mà vẫn hợp lệ.")
    out = []
    for a, b in combinations(ids, 2):
        if mode == "vs_reference" and reference not in (a, b):
            continue
        if reference is not None and b == reference:
            a, b = b, a
        out.append((a, b))
    return out


def compare_pairs(scores: dict[str, pd.DataFrame], metrics: list[str],
                  cfg_stats: dict, arm_ids: list[str],
                  seed: int = 42) -> pd.DataFrame:
    """Một dòng cho mỗi (cặp × metric). Hiệu số là B − A."""
    alpha = float(cfg_stats.get("alpha", 0.05))
    n_perm = int(cfg_stats.get("n_perm", 10000))
    n_boot = int(cfg_stats.get("n_boot", 10000))
    ci_method = str(cfg_stats.get("ci_method", "bca"))
    dz_floor = float(cfg_stats.get("dz_floor", 0.10))
    scope = str(cfg_stats.get("adjust_scope", "pairs")).lower()
    pairs = pair_list(arm_ids, cfg_stats.get("pairs", "all"),
                      cfg_stats.get("reference"))

    # MỘT generator cho cả bảng, tiêu tuần tự theo (cặp, metric). Một generator
    # mới cho mỗi cặp nghĩa là ba cặp dùng CÙNG dãy hoán vị — các p-value khi ấy
    # tương quan với nhau theo một cách không ai khai báo, và Holm giả định
    # ngược lại.
    rng = np.random.default_rng(seed)

    rows = []
    for arm_a, arm_b in pairs:
        for m in metrics:
            a = scores[arm_a][m].to_numpy(dtype=np.float64)
            b = scores[arm_b][m].to_numpy(dtype=np.float64)
            d = b - a
            bs = paired_bootstrap(d, n_boot, rng, alpha=alpha, method=ci_method)
            pm = permutation_paired(d, n_perm, rng)
            n_tie = int(np.count_nonzero(d == 0.0))
            rows.append({
                "pair": f"{arm_b}_vs_{arm_a}", "arm_a": arm_a, "arm_b": arm_b,
                "metric": m, "n": d.size,
                "mean_a": float(a.mean()), "mean_b": float(b.mean()),
                "mean_diff": bs["mean_diff"],
                "rel_diff_pct": (100.0 * bs["mean_diff"] / abs(a.mean())
                                 if a.mean() else float("nan")),
                "ci_lo": bs["ci_lo"], "ci_hi": bs["ci_hi"],
                "ci_method": bs["ci_method"], "boot_se": bs["boot_se"],
                "p_perm": pm["p_perm"], "p_boot": bs["p_boot"],
                "cohen_dz": cohen_dz(d),
                "win_rate_b": float(np.mean(d > 0)),
                "win_b": int(np.count_nonzero(d > 0)),
                "win_a": int(np.count_nonzero(d < 0)),
                "tie": n_tie, "n_tied": n_tie,
                "frac_tied": n_tie / max(1, d.size),
            })
    df = pd.DataFrame(rows)
    if df.empty:
        return df

    # ── Holm, theo họ đã khai ──────────────────────────────────────────────
    if scope == "pairs":
        group = df["metric"]
    elif scope == "metrics":
        group = df["pair"]
    elif scope == "all":
        group = pd.Series("all", index=df.index)
    else:
        raise ValueError(
            f"stats.adjust_scope = {scope!r}; hợp lệ: 'pairs' | 'metrics' | "
            f"'all'. Không có mặc định ngầm ở đây — họ hiệu chỉnh quyết định "
            f"bao nhiêu dòng sống sót, và một mặc định lặng lẽ là một bảng "
            f"p-value không tái lập được.")
    for col in ("p_perm", "p_boot"):
        adj = np.empty(len(df), dtype=np.float64)
        for _key, idx in df.groupby(group).groups.items():
            pos = df.index.get_indexer(idx)
            adj[pos] = holm(df.loc[idx, col].to_numpy())
        df[f"{col}_holm"] = adj

    df["sig_perm"] = df["p_perm_holm"] < alpha
    df["sig_boot"] = df["p_boot_holm"] < alpha
    df["material"] = df["cohen_dz"].abs() >= dz_floor
    df["significant"] = df["sig_perm"] & df["sig_boot"]
    df["significant_and_material"] = df["significant"] & df["material"]
    df["ci_excludes_zero"] = (df["ci_lo"] > 0) | (df["ci_hi"] < 0)
    df["winner"] = np.where(
        ~df["significant_and_material"], "—",
        np.where(df["mean_diff"] > 0, df["arm_b"], df["arm_a"]))
    df["dz_warning"] = [
        materiality_warning(int(r.n), float(r.cohen_dz), dz_floor)
        if bool(r.significant) else None for r in df.itertuples(index=False)]
    df["adjust_scope"] = scope
    # Bí danh cho phía báo cáo — `report_recomb.normalize_pw` của §2.3 đọc
    # `diff`/`better`, và giữ chúng ở đây nghĩa là một bảng CSV của §2.5 vẫn mở
    # được bằng công cụ cũ mà không phải đổi tên cột.
    df["diff"] = df["mean_diff"]
    df["better"] = df["winner"]
    return df


def summary_lines(df: pd.DataFrame, primary: str, names: dict[str, str]) -> list[str]:
    """Một câu kết luận cho MỖI cặp, trên metric chính."""
    out = []
    sub = df[df["metric"] == primary]
    if sub.empty:
        return [f"Không có metric chính `{primary}` trong bảng."]
    for r in sub.itertuples(index=False):
        na = names.get(r.arm_a, r.arm_a)
        nb = names.get(r.arm_b, r.arm_b)
        head = (f"`{primary}` · {nb} − {na} = {r.mean_diff:+.4f} "
                f"(95% CI [{r.ci_lo:+.4f}, {r.ci_hi:+.4f}], dz={r.cohen_dz:.3f})")
        if not bool(r.significant):
            out.append(f"{head} — KHÔNG bác được H0 (p_perm={r.p_perm_holm:.3g}, "
                       f"p_boot={r.p_boot_holm:.3g} sau Holm).")
        elif not bool(r.material):
            out.append(f"{head} — có ý nghĩa thống kê nhưng |dz| dưới sàn: ở "
                       f"n={int(r.n)} đó là điều phải chờ đợi, không phải một "
                       f"phát hiện.")
        else:
            out.append(f"{head} — **{names.get(r.winner, r.winner)} thắng**, cả "
                       f"permutation lẫn bootstrap đều bác H0 sau Holm "
                       f"(thắng {100 * r.win_rate_b:.1f}% số ảnh).")
    return out
