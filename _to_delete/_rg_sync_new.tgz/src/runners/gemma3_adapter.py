"""Gemma 3 4B + một adapter đã huấn luyện — runner của §2.2, giữ lại để chạy lại.

Kế thừa nguyên `Gemma3Runner` của §2.1 (cùng prompt, cùng cách cắt token sinh
ra, cùng vòng resume/ngắt mạch) và chỉ thay bước NẠP.

Một điều duy nhất phải làm đúng ở đây, và nó không tự lộ ra nếu làm sai:

    arm nào huấn luyện trên base 4-bit thì PHẢI sinh trên base 4-bit.

Gắn adapter QLoRA lên base bf16 vẫn nạp được, vẫn sinh ra văn bản đọc được, và
điểm số vẫn ở mức hợp lý — nên không có gì báo động. Nhưng model được chấm khi
đó KHÔNG phải model đã huấn luyện: trọng số nền khác, và toàn bộ ý nghĩa của
cột "QLoRA vs LoRA" trong bảng Friedman bốc hơi. `train_stats.json` ghi lại
arm nào lượng tử, và runner đọc lại từ đó chứ không đoán theo tên arm.

§2.3 KHÔNG dùng runner này cho candidate A — cả hai candidate đi
`gemma3_recomb` để hai cột dùng chung một đường sinh. Xem docstring file đó.
"""
from __future__ import annotations

import json
from pathlib import Path

from .. import imaging
from ..config import hf_token
from .base import RunnerUnusable
from .gemma3 import Gemma3Runner


def _infer_device_map(cfg):
    from ..backbone import device_map_for

    return device_map_for(cfg, for_training=False)


class Gemma3AdapterRunner(Gemma3Runner):
    name = "gemma3_adapter"

    def load(self) -> None:
        import torch
        from transformers import AutoProcessor, Gemma3ForConditionalGeneration

        adapter_dir = Path(str(self.mcfg["adapter_dir"]))
        if not adapter_dir.exists():
            raise RunnerUnusable(
                f"không thấy adapter ở {adapter_dir}. Chạy stage `train` trước, "
                f"hoặc `--stages train,infer,...`.")
        stats_path = adapter_dir / "train_stats.json"
        if not stats_path.exists() and self.mcfg.get("weights_only"):
            # Infer cưỡng bức: chỉ cần TRỌNG SỐ. Suy các tham số nạp từ config + file adapter,
            # không đòi train_stats.json (không phụ thuộc train xong hay chưa).
            tq = (self.cfg.get("train", {}) or {}).get("quant", {}) or {}
            stats = {"quantized": bool(tq.get("load_in_4bit", True)),
                     "projector_adapter": (adapter_dir / "projector_adapter.json").exists()}
            print(f"  ⚠ {adapter_dir.name}: không có train_stats.json — infer cưỡng bức "
                  f"dùng trọng số + config hiện tại (quantized={stats['quantized']})", flush=True)
        elif not stats_path.exists():
            # Không có file này nghĩa là lần huấn luyện trước chết giữa lúc ghi.
            # Adapter cụt nạp được nhưng sinh ra rác, và rác đó sẽ thành một cột
            # số trông như kết quả thật trong bảng tám arm.
            raise RunnerUnusable(
                f"{adapter_dir} thiếu train_stats.json — adapter ghi dở. Xoá thư "
                f"mục đó rồi chạy lại stage `train`.")
        else:
            stats = json.loads(stats_path.read_text(encoding="utf-8"))

        # NGUỒN SỰ THẬT là file thống kê của lần huấn luyện, không phải config
        # hiện tại: config có thể đã bị --set sửa từ lần train tới lần infer.
        quantized = bool(stats.get("quantized", False))
        hf_id = self.mcfg["hf_id"]
        tok = hf_token()
        dt = self.torch_dtype()
        # device_map của khâu SINH lấy từ base.device_map_infer (mặc định
        # "auto"). Khác đường huấn luyện, ở đây offload sang CPU là chấp nhận
        # được: chậm, nhưng hook của accelerate cho ra đúng kết quả.
        kw = dict(token=tok, torch_dtype=dt,
                  device_map=_infer_device_map(self.cfg),
                  attn_implementation=str(self.mcfg.get("attn_implementation", "sdpa")))
        if quantized:
            from ..backbone import quant_config

            kw["quantization_config"] = quant_config(dict(self.cfg.get("train", {})))
            print(f"  nạp {hf_id} ở 4-bit (arm này huấn luyện trên base lượng tử)",
                  flush=True)
        else:
            print(f"  nạp {hf_id} ở {dt}", flush=True)

        self.processor = AutoProcessor.from_pretrained(hf_id, token=tok)
        # padding_side=left cho khâu SINH (ngược với khâu train). Với padding
        # phải, pad token nằm SAU prompt và model sinh tiếp từ pad -> đầu ra bắt
        # đầu bằng rác. Lỗi này không ném exception, nó chỉ làm điểm tụt.
        self.processor.tokenizer.padding_side = "left"
        self._apply_image_policy()

        # Cùng lý lẽ với `quantized` ở trên, áp cho ẢNH: arm nào huấn luyện với
        # ảnh 512 và pan&scan tắt thì phải SINH y như vậy. Lệch nhau vẫn chạy
        # trơn, vẫn ra văn bản đọc được, chỉ là adapter bị chấm trên phân phối
        # đầu vào khác phân phối nó học — và cột số ấy vẫn trông như kết quả
        # thật trong bảng tám arm.
        want = imaging.policy(self.cfg)
        for key, now in (("image_max_side",
                          int((self.cfg.get("data", {}) or {}).get("image_max_side", 512))),
                         ("do_pan_and_scan", bool(want["do_pan_and_scan"]))):
            was = stats.get(key)
            if was is not None and was != now:
                raise RunnerUnusable(
                    f"arm này huấn luyện với {key}={was}, còn cấu hình lúc sinh "
                    f"là {now}. Sinh với ảnh khác lúc train là chấm một model "
                    f"khác model đã huấn luyện.\n"
                    f"    Sửa config cho khớp, hoặc xoá {adapter_dir} rồi huấn "
                    f"luyện lại arm này.")

        base = Gemma3ForConditionalGeneration.from_pretrained(hf_id, **kw)
        from peft import PeftModel

        self.model = PeftModel.from_pretrained(base, str(adapter_dir)).eval()
        if stats.get("projector_adapter"):
            from .. import proj_adapter

            proj_adapter.load(self.model, adapter_dir)
            print("  ✓ đã nạp projector adapter", flush=True)

        # Hợp nhất adapter vào trọng số nền cho nhanh — CHỈ khi base không lượng
        # tử. merge_and_unload trên base 4-bit phải giải lượng tử toàn bộ trọng
        # số (dựng lại ~8 GB fp16), tức là vứt đúng thứ mà arm chữ Q đang đo.
        if not quantized and bool(self.mcfg.get("merge_adapter", True)):
            try:
                self.model = self.model.merge_and_unload().eval()
                print("  ✓ đã hợp nhất adapter vào base (sinh nhanh hơn)", flush=True)
            except Exception as e:
                print(f"  ⚠ không hợp nhất được adapter ({e!r}) — chạy dạng peft", flush=True)

        _ = torch
        print(f"  ✓ {self.mcfg['id']}: {hf_id} + {adapter_dir.name} "
              f"(r={stats.get('rank')}, alpha={stats.get('alpha')}, "
              f"dora={stats.get('dora')}, 4bit={quantized})", flush=True)
