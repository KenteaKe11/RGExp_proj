#!/usr/bin/env python
"""Tạo split cấp PATIENT: mỗi patient đúng một ảnh, train/val/test không giao nhau.

    python scripts/make_patient_split.py --out data/splits_patient_v2 \
        --n-train 12800 --n-val 256 --n-test 3000 --seed 42

Patient lấy từ cột `--patient-col` (mặc định `subject_id`) của clean_dataset.csv
nếu có, không thì từ đường dẫn ảnh dạng .../p10/p10000032/s5xxxx/x.jpg.
Mỗi patient chọn NGẪU NHIÊN một ảnh (seed cố định), rồi patient được chia ngẫu
nhiên cho train/val/test. `--exclude-test-csv` loại thêm các patient của một tập
test cũ (nếu muốn test mới cũng không trùng test cũ).
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.config import load_config, hf_token  # noqa: E402

PAT = re.compile(r"(?:^|/)p(\d{8})(?:/|$)")


def patient_of(key: str) -> str | None:
    m = PAT.search(key.replace("\\", "/"))
    return m.group(1) if m else None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/recombiner.yaml")
    ap.add_argument("--out", default="data/splits_patient_v2")
    ap.add_argument("--n-train", type=int, default=12800)
    ap.add_argument("--n-val", type=int, default=256)
    ap.add_argument("--n-test", type=int, default=3000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--patient-col", default="subject_id")
    ap.add_argument("--exclude-test-csv", default=None,
                    help="CSV test cũ; patient trong đó bị loại khỏi cả ba tập")
    ap.add_argument("--upload", action="store_true",
                    help="đẩy ba file lên repo dataset (cần token ghi)")
    a = ap.parse_args()

    from huggingface_hub import hf_hub_download
    cfg = load_config(a.config)
    d = cfg.data
    kc, rc = d["key_column"], d["ref_column"]
    meta_path = hf_hub_download(repo_id=d["repo"], repo_type=d.get("repo_type", "dataset"),
                                filename=d["meta_csv"], token=hf_token())
    head = pd.read_csv(meta_path, nrows=0).columns
    cols = [kc, rc] + ([a.patient_col] if a.patient_col in head else [])
    meta = pd.read_csv(meta_path, usecols=cols)
    meta[kc] = meta[kc].astype(str)
    meta = meta[meta[rc].astype(str).str.strip().ne("") & meta[rc].notna()]
    if a.patient_col in meta.columns:
        meta["_pid"] = meta[a.patient_col].astype(str)
    else:
        meta["_pid"] = meta[kc].map(patient_of)
    if meta["_pid"].isna().any():
        bad = meta.loc[meta["_pid"].isna(), kc].head(3).tolist()
        raise SystemExit(f"Không suy ra được patient cho {meta['_pid'].isna().sum()} key, ví dụ {bad}. "
                         "Đặt --patient-col cho đúng cột.")
    print(f"{len(meta)} ảnh, {meta['_pid'].nunique()} patient")

    if a.exclude_test_csv:
        old = pd.read_csv(a.exclude_test_csv)[kc].astype(str)
        old_p = set(meta.loc[meta[kc].isin(set(old)), "_pid"])
        meta = meta[~meta["_pid"].isin(old_p)]
        print(f"loại {len(old_p)} patient của test cũ")

    rng = np.random.default_rng(a.seed)
    meta = meta.sample(frac=1.0, random_state=a.seed)          # xáo, rồi giữ ảnh đầu của mỗi patient
    one = meta.drop_duplicates("_pid", keep="first").reset_index(drop=True)
    need = a.n_train + a.n_val + a.n_test
    if len(one) < need:
        raise SystemExit(f"Chỉ có {len(one)} patient, cần {need}.")
    idx = rng.permutation(len(one))[:need]
    one = one.iloc[idx].reset_index(drop=True)
    parts = {"test": one.iloc[:a.n_test],
             "val": one.iloc[a.n_test:a.n_test + a.n_val],
             "train": one.iloc[a.n_test + a.n_val:]}

    for n, x in parts.items():
        for m, y in parts.items():
            if n < m:
                assert not (set(x["_pid"]) & set(y["_pid"])), f"patient trùng {n}/{m}"
                assert not (set(x[kc]) & set(y[kc])), f"key trùng {n}/{m}"
        assert x["_pid"].is_unique, f"{n}: một patient xuất hiện hai lần"

    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    for n, x in parts.items():
        x[[kc]].to_csv(out / f"{n}_split.csv", index=False)
        print(f"  {n}: {len(x)} ảnh / {x['_pid'].nunique()} patient -> {out / (n + '_split.csv')}")
    print(f"seed={a.seed}; thứ tự file cố định, n_train lấy từ ĐẦU file.")

    if a.upload:
        from huggingface_hub import HfApi
        api = HfApi(token=hf_token())
        for n in parts:
            api.upload_file(path_or_fileobj=str(out / f"{n}_split.csv"),
                            path_in_repo=f"split_ref_patient_v2/{n}_split.csv",
                            repo_id=d["repo"], repo_type=d.get("repo_type", "dataset"))
        print("đã đẩy lên split_ref_patient_v2/")


if __name__ == "__main__":
    main()
