"""Chọn nơi đọc file split: thư mục cục bộ (nếu khai) hoặc repo HF.

`data.split_local_dir` trỏ tới thư mục chứa train_split.csv / val_split.csv /
test_split.csv do `scripts/make_patient_split.py` tạo (mỗi patient đúng một ảnh,
ba tập không giao nhau về patient). Thiếu một file trong thư mục đó thì DỪNG,
không lặng lẽ quay về split cũ trên Hub — vì khi đó train và test thuộc hai
phiên bản split khác nhau mà không ai biết.
"""
from __future__ import annotations

from pathlib import Path


def resolve_split_file(cfg, filename: str) -> str:
    d = cfg.data
    local_dir = d.get("split_local_dir")
    if local_dir:
        p = Path(local_dir).expanduser() / Path(filename).name
        if not p.exists():
            raise FileNotFoundError(
                f"data.split_local_dir={local_dir} nhưng thiếu {p.name}. "
                "Chạy `python scripts/make_patient_split.py` trước.")
        return str(p)
    from huggingface_hub import hf_hub_download
    from .config import hf_token
    return hf_hub_download(repo_id=d["repo"], repo_type=d.get("repo_type", "dataset"),
                           filename=filename, token=hf_token())
