"""Khung chung cho mọi runner infer.

Ba model, ba thư viện, ba kiểu prompt — nhưng CÙNG một hợp đồng: nhận
[key, ref, image_path], trả về một dòng JSONL mỗi ảnh. Nhờ đó khâu chấm điểm
không cần biết model nào sinh ra file nào, và LLaVA-Med (chạy ở venv khác, qua
subprocess) ghép vào đúng chỗ mà không phải chừa ngoại lệ.

RESUME là bắt buộc chứ không phải tiện nghi: 3 model × 3000 ảnh trên máy thuê
tính tiền theo giờ, và một lần OOM ở ảnh 2400 mà phải chạy lại từ 0 là mất
tiền thật.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import pandas as pd

from ..config import Cfg
from ..preflight import c_compiler_works, diagnose
from ..tracking import NullTracker


class RunnerUnusable(RuntimeError):
    """Model này KHÔNG chạy được trên máy/môi trường hiện tại.

    Khác hẳn "một vài ảnh hỏng": ở đây mọi ảnh sẽ hỏng như nhau, nên đi tiếp
    chỉ tạo ra 3000 chuỗi rỗng và một bảng điểm toàn số 0 — trông như một kết
    quả thật. Dừng model này lại và nói rõ vì sao.
    """



def repair_tail(path: Path) -> int:
    """Cắt bỏ dòng CUỐI nếu nó chưa kết thúc bằng newline. Trả số byte đã bỏ.

    Ctrl-C (hay máy thuê hết giờ) giữa lúc ghi để lại một dòng JSON cụt. Mở
    tiếp ở chế độ append thì bản ghi mới bị NỐI THẲNG vào dòng cụt đó, và file
    mang một dòng hỏng vĩnh viễn: khâu đọc bỏ qua được, nhưng bất cứ ai — hay
    công cụ nào — đọc file sau này cũng vấp phải nó, và ảnh nằm trong dòng đó
    thì im lặng biến mất khỏi kết quả.

    Rẻ hơn nhiều nếu dọn ngay lúc mở file, trước khi ghi thêm gì.
    """
    if not path.exists() or path.stat().st_size == 0:
        return 0
    with open(path, "rb+") as f:
        f.seek(-1, 2)
        if f.read(1) == b"\n":
            return 0
        size = path.stat().st_size
        # Quét ngược tìm newline cuối. Dòng JSONL ở đây dài vài trăm byte tới
        # vài KB, nên đọc lùi 1 MB là quá đủ mà không phải nạp cả file.
        window = min(size, 1 << 20)
        f.seek(size - window)
        tail = f.read(window)
        nl = tail.rfind(b"\n")
        keep = size - window + nl + 1 if nl >= 0 else 0
        f.truncate(keep)
        return size - keep


class Runner:
    """Lớp cơ sở. Con lớp cài `load`, `generate_batch`, (tuỳ chọn) `unload`."""

    name = "base"

    def __init__(self, cfg: Cfg, mcfg: Cfg, tracker=None):
        self.cfg = cfg
        self.mcfg = mcfg
        self.model = None
        self.processor = None
        self.tracker = tracker or NullTracker()
        # Móc checkpoint (tuỳ chọn): `checkpoint(tổng_số_mẫu_đã_xong)` được gọi SAU MỖI
        # BATCH, khi file predictions đã flush. src/resume.py dùng nó để cập nhật metadata
        # cố định và đẩy predictions dở lên Hub, nên shutdown giữa lúc sinh chỉ mất vài
        # trăm mẫu. Lỗi trong móc này không bao giờ làm hỏng lần sinh.
        self.checkpoint = None
        # Optional per-sample side outputs (e.g. classification-head decisions).
        self._last_batch_aux: dict[str, dict] = {}

    @property
    def required_prediction_fields(self) -> tuple[str, ...]:
        """Extra JSONL fields required for a prediction to count as resumable."""
        return ()

    # ── giao diện con lớp phải cài ──────────────────────────────────────────
    def load(self) -> None:
        raise NotImplementedError

    def generate_batch(self, batch: list[dict]) -> list[str]:
        """batch = [{key, ref, image_path}] -> danh sách văn bản sinh ra."""
        raise NotImplementedError

    def unload(self) -> None:
        self.model = None
        self.processor = None
        try:
            import gc

            import torch

            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except ImportError:
            pass

    # ── phần dùng chung ─────────────────────────────────────────────────────
    def torch_dtype(self):
        """Chọn dtype thật, có tính tới GPU có bf16 hay không.

        Gemma 3 là ngoại lệ và phải xử riêng: fp16 tràn số ở layer 5 (loss/logit
        thành NaN, model sinh ra chuỗi rỗng hoặc rác) nên trên GPU không bf16 nó
        đi fp32 — chậm hơn ~2-3× nhưng ra số đọc được, còn fp16 thì không.
        """
        import torch

        want = str(self.mcfg.get("dtype", "bfloat16"))
        table = {"bfloat16": torch.bfloat16, "float16": torch.float16, "float32": torch.float32}
        dt = table.get(want, torch.bfloat16)
        if dt is torch.bfloat16 and torch.cuda.is_available() \
                and not torch.cuda.is_bf16_supported():
            fallback = torch.float32 if self.name == "gemma3" else torch.float16
            print(f"  ⚠ GPU không có bf16 -> {self.name} dùng {fallback}", flush=True)
            return fallback
        return dt

    def gen_kwargs(self) -> dict:
        """kwargs của `transformers.generate` — đặc tả giải mã CHUNG của §2.5
        (`src/decoding_spec.py`), cùng luật với beam search của R2Gen/AdaAtt."""
        from ..decoding_spec import DecodingSpecError, hf_kwargs

        try:
            kw = hf_kwargs(self.cfg)
        except DecodingSpecError as e:
            raise RunnerUnusable(str(e)) from e
        return kw

    # ── vòng chạy ───────────────────────────────────────────────────────────
    def run(self, df: pd.DataFrame, out_path: Path, log_every: int = 20) -> Path:
        out_path.parent.mkdir(parents=True, exist_ok=True)

        cut = repair_tail(out_path)
        if cut:
            print(f"  ⚠ dọn {cut} byte của dòng cuối bị cắt dở (lần chạy trước bị dừng "
                  f"giữa lúc ghi)", flush=True)

        try:
            from ..decoding_spec import tag as _decode_tag

            decode_tag = _decode_tag(self.cfg)
        except Exception:  # noqa: BLE001 — nhãn chỉ để đối chiếu, không chặn sinh
            decode_tag = None
        records: dict[str, dict] = {}
        if out_path.exists():
            # Đọc lại bằng try/except từng dòng: file bị cắt giữa chừng vì
            # Ctrl-C thì chỉ dòng CUỐI hỏng, và vứt cả file vì một dòng cụt là
            # phí hàng giờ GPU đã trả tiền.
            with open(out_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        record = json.loads(line)
                        records[str(record["key"])] = record
                    except Exception:
                        continue
        required = set(self.required_prediction_fields)
        if required:
            # Old prediction caches may contain the report but not the newly
            # requested side output. Keep complete rows, discard stale rows,
            # then regenerate only those samples and write fresh records.
            complete = {k: r for k, r in records.items()
                        if required.issubset(r)}
            if len(complete) != len(records):
                with open(out_path, "w", encoding="utf-8") as f:
                    for record in complete.values():
                        f.write(json.dumps(record, ensure_ascii=False) + "\n")
                records = complete
        done = set(records)
        if records:
            print(f"  resume: đã có {len(done)} mẫu trong {out_path.name}", flush=True)

        todo = [r._asdict() if hasattr(r, "_asdict") else dict(r)
                for r in df.itertuples(index=False)]
        todo = [r for r in todo if str(r["key"]) not in done]
        if not todo:
            print(f"  ✓ {self.name}: đã đủ {len(done)} mẫu, bỏ qua", flush=True)
            return out_path

        print(f"  {self.name}: còn {len(todo)}/{len(df)} mẫu cần sinh", flush=True)
        self.load()
        self.configure_compile()
        self.smoke_test(todo[0])

        bs = max(1, int(self.mcfg.get("batch_size", 1)))
        # Dò batch khi sinh: bắt đầu ở bậc lớn nhất của `batch_probe_sizes`, gặp
        # OOM thì dọn VRAM, hạ xuống bậc kế và thử lại CHÍNH batch đó; bậc đã hạ
        # được giữ cho phần còn lại (không dò lại mỗi batch).
        ladder = ([int(x) for x in (self.mcfg.get("batch_probe_sizes") or [])]
                  if bool(self.mcfg.get("batch_probe", False)) else [])
        ladder = sorted({x for x in ladder if x >= 1}, reverse=True)
        planner = None
        if ladder:
            from ..batch_ladder import VramPlanner
            planner = VramPlanner()
            planner.begin("trước infer")
            bs = ladder[0]
            print(f"  dò batch sinh: bắt đầu {bs} (hiệu chỉnh theo VRAM trống ở batch đầu)",
                  flush=True)
        t0 = time.time()
        n_done = 0
        n_empty = 0
        n_batch_failed = 0
        fail_streak = 0
        limit = max(1, int(self.mcfg.get("consecutive_fail_limit", 3)))
        samples: list[dict] = []
        with open(out_path, "a", encoding="utf-8") as f:
            i = 0
            n_batches = 0
            while i < len(todo):
                cal = planner is not None and planner.pending
                batch = todo[i:i + (min(4, bs) if cal else bs)]
                t1 = time.time()
                try:
                    self._last_batch_aux = {}
                    outs = self.generate_batch(batch)
                    batch_aux = self._last_batch_aux
                    fail_streak = 0
                    if cal:
                        from ..batch_ladder import trim_ladder
                        cap_b = planner.cap(len(batch))
                        ladder = trim_ladder(ladder, cap_b)
                        bs = min(bs, ladder[0])
                except Exception as e:
                    if ladder:
                        from ..backbone import is_oom

                        smaller = [x for x in ladder if x < bs]
                        if is_oom(e) and smaller:
                            print(f"  OOM ở batch sinh {bs}; dọn VRAM, hạ xuống "
                                  f"{smaller[0]} và thử lại batch này.", flush=True)
                            del e
                            self._free()
                            bs = smaller[0]
                            if planner is not None:
                                planner.pending = False
                            continue
                    # Một batch hỏng (OOM, ảnh lỗi, prompt quá dài) KHÔNG được
                    # giết cả lần chạy. Thử lại từng ảnh một — phần lớn ca OOM
                    # là do batch, không do ảnh — rồi ghi chuỗi rỗng cho ảnh
                    # thật sự hỏng và đi tiếp.
                    self._report_error(e)
                    n_batch_failed += 1
                    self._free()
                    outs = []
                    batch_aux = {}
                    n_item_fail = 0
                    for item in batch:
                        try:
                            self._last_batch_aux = {}
                            outs.extend(self.generate_batch([item]))
                            batch_aux.update(self._last_batch_aux)
                        except Exception as e2:
                            n_item_fail += 1
                            self._report_error(e2, key=item["key"])
                            outs.append("")
                            self._free()
                    # ── NGẮT MẠCH ──────────────────────────────────────────
                    # Cả batch hỏng VÀ từng ảnh cũng hỏng, nhiều lần liên tiếp:
                    # đây không phải vài ảnh xấu mà là môi trường sai. Đi tiếp
                    # chỉ để sinh ra 3000 dòng rỗng rồi báo "xong" — chính xác
                    # cái đã đốt một lần chạy nhiều giờ. Dừng model này lại.
                    if n_item_fail == len(batch):
                        fail_streak += 1
                        if fail_streak >= limit:
                            raise RunnerUnusable(
                                f"{limit} batch liên tiếp hỏng HOÀN TOÀN "
                                f"({n_done}/{len(todo)} mẫu). Lỗi cuối: {e!r}"
                                + (f"\n    → {diagnose(e)}" if diagnose(e) else "")
                            ) from e
                    else:
                        fail_streak = 0
                dt = time.time() - t1
                for item, text in zip(batch, outs):
                    if not text.strip():
                        n_empty += 1
                    if len(samples) < int(self.cfg.get_path("wandb.log_samples", 20) or 0):
                        # Vài mẫu văn bản thật, gửi lên sớm. Nhìn số BLEU không
                        # phân biệt được "model viết sai" với "model từ chối trả
                        # lời" hay "prompt dính vào output" — ba ca cần ba cách
                        # sửa khác hẳn nhau, và biết ở phút thứ 5 rẻ hơn nhiều
                        # so với biết sau ba giờ.
                        samples.append({"key": item["key"], "ref": item.get("ref", "")[:600],
                                        "pred": text[:600]})
                    record = {
                        "key": item["key"],
                        "pred": text,
                        "model_id": self.mcfg["id"],
                        "decode": decode_tag,
                        "latency_s": round(dt / max(1, len(batch)), 3),
                        "empty": not text.strip(),
                    }
                    record.update(batch_aux.get(str(item["key"]), {}))
                    f.write(json.dumps(record, ensure_ascii=False) + "\n")
                f.flush()
                n_done += len(batch)
                i += len(batch)
                n_batches += 1
                if self.checkpoint is not None:
                    try:
                        self.checkpoint(len(done) + n_done)
                    except Exception as e:  # noqa: BLE001
                        print(f"  ⚠ checkpoint lỗi ({e!r}) — bỏ qua", flush=True)
                if n_batches % log_every == 0 or n_done >= len(todo):
                    rate = n_done / max(1e-9, time.time() - t0)
                    eta = (len(todo) - n_done) / max(1e-9, rate)
                    print(f"  [{self.name}] {n_done}/{len(todo)} | {rate:.2f} ảnh/s "
                          f"| còn ~{eta/60:.1f} phút", flush=True)
                    mid = self.mcfg["id"]
                    self.tracker.log({
                        f"infer/{mid}/done": len(done) + n_done,
                        f"infer/{mid}/total": len(df),
                        f"infer/{mid}/pct": 100.0 * (len(done) + n_done) / max(1, len(df)),
                        f"infer/{mid}/rate_img_s": rate,
                        f"infer/{mid}/eta_min": eta / 60,
                        f"infer/{mid}/n_empty": n_empty,
                        f"infer/{mid}/n_batch_failed": n_batch_failed,
                        **self._vram(),
                    })

        self.unload()
        mins = (time.time() - t0) / 60
        mid = self.mcfg["id"]
        self.tracker.samples(f"samples/{mid}", samples)
        self.tracker.summary({
            f"infer/{mid}/minutes": round(mins, 1),
            f"infer/{mid}/n_generated": n_done,
            f"infer/{mid}/n_empty": n_empty,
            f"infer/{mid}/n_batch_failed": n_batch_failed,
        })
        print(f"✓ {self.name}: xong sau {mins:.1f} phút -> {out_path}", flush=True)
        return out_path

    def configure_compile(self) -> None:
        """Quyết định có để torch.compile chạy hay không, và luôn giăng lưới.

        transformers TỰ BẬT torch.compile cho đường sinh của Gemma 3 — không
        phải ta yêu cầu. inductor sinh mã C++/CUDA rồi gọi trình biên dịch thật
        để dịch, và trên ảnh container việc đó đã hỏng HAI lần vì HAI lý do
        khác nhau:

            1. không có gcc          -> "Failed to find C compiler"
            2. CÓ gcc, thiếu Python.h -> gcc chạy rồi trả về exit 1

        Lần một tôi vá bằng `which gcc`. Lần hai chứng minh phép kiểm đó sai:
        có compiler không đồng nghĩa với dịch được. Nên giờ `auto` DỊCH THỬ một
        file C thật (chưa tới một giây) thay vì suy từ một dấu hiệu gián tiếp.

        Và bất kể quyết định thế nào, `suppress_errors` vẫn được bật: nếu còn
        chỗ nào gọi compile mà ta chưa biết, hoặc dịch thử qua được nhưng
        triton vẫn hỏng vì một lý do thứ ba, nó rơi về eager thay vì giết cả
        lần chạy. Compile chỉ là tối ưu tốc độ — không đáng để mất kết quả.

        `models[].disable_compile`: auto (mặc định) | true | false
        """
        # ── Lưới an toàn, luôn giăng ────────────────────────────────────────
        try:
            import torch._dynamo

            torch._dynamo.config.suppress_errors = True
        except Exception:
            pass

        want = str(self.mcfg.get("disable_compile", "auto")).lower()
        if want in ("false", "0", "no", "off"):
            return
        if want in ("true", "1", "yes", "on"):
            why = "models[].disable_compile=true"
        else:
            ok, detail = c_compiler_works()
            if ok:
                print(f"  ⚙ dịch thử mã C OK ({detail}) -> để torch.compile chạy",
                      flush=True)
                return
            why = f"dịch thử mã C hỏng: {detail}"

        print(f"  ⚙ tắt torch.compile ({why}) -> chạy eager", flush=True)
        try:
            import torch._dynamo

            torch._dynamo.reset()
        except Exception:
            pass
        try:
            if self.model is not None and getattr(self.model, "generation_config", None):
                # Khoá chính thức của transformers (>= 4.48). Đặt trên
                # generation_config chứ không truyền vào generate(): bản cũ hơn
                # sẽ coi nó là kwarg lạ và cảnh báo ở MỖI batch.
                self.model.generation_config.disable_compile = True
        except Exception:
            pass

    def smoke_test(self, item: dict) -> None:
        """Sinh THỬ đúng một ảnh ngay sau khi nạp model.

        Vài giây này là ranh giới giữa "biết ngay môi trường sai" và "ba giờ sau
        mới biết, qua một bảng điểm toàn số 0". Mọi lỗi tương thích đã gặp
        (torch quá cũ cho mask của Gemma 3, remote code đòi API đã bị bỏ,
        flash-attn thiếu, token không có quyền) đều lộ ra ở lần generate đầu
        tiên chứ không phải ở ảnh thứ 2000.
        """
        try:
            out = self.generate_batch([item])
        except Exception as e:
            hint = diagnose(e)
            raise RunnerUnusable(
                f"sinh thử một ảnh đã hỏng: {e!r}" + (f"\n    → {hint}" if hint else "")
            ) from e
        if not out or not out[0].strip():
            # Không ném exception nhưng ra chuỗi rỗng: cũng là hỏng, chỉ là im
            # lặng hơn. Hay gặp khi thiếu placeholder ảnh trong prompt, hoặc khi
            # cắt nhầm phần sinh mới.
            raise RunnerUnusable(
                "sinh thử một ảnh ra CHUỖI RỖNG. Model nạp được nhưng không sinh "
                "được gì — kiểm prompt/placeholder ảnh và chỗ cắt token đầu ra.")
        preview = out[0].strip().replace("\n", " ")[:160]
        print(f"  ✓ sinh thử OK: {preview}...", flush=True)

    def _report_error(self, exc: BaseException, key: str | None = None) -> None:
        """In lỗi MỘT lần cho mỗi loại, kèm cách sửa nếu nhận ra.

        Không có phần "một lần" thì log là 3000 dòng giống hệt nhau, và dòng
        hữu ích duy nhất — nguyên nhân — chìm nghỉm trong đó.
        """
        sig = f"{type(exc).__name__}:{str(exc)[:120]}"
        seen = getattr(self, "_seen_errors", None)
        if seen is None:
            seen = self._seen_errors = {}
        seen[sig] = seen.get(sig, 0) + 1
        where = f"{key}: " if key else ""
        if seen[sig] == 1:
            print(f"  ✗ {where}{exc!r}", flush=True)
            hint = diagnose(exc)
            if hint:
                print(f"    → {hint}", flush=True)
        elif seen[sig] in (10, 100, 1000):
            print(f"  ✗ (lỗi này đã lặp {seen[sig]} lần) {sig[:80]}", flush=True)

    @staticmethod
    def _vram() -> dict:
        try:
            import torch

            if not torch.cuda.is_available():
                return {}
            return {"sys/vram_alloc_gb": torch.cuda.memory_allocated() / 1024 ** 3,
                    "sys/vram_peak_gb": torch.cuda.max_memory_allocated() / 1024 ** 3}
        except Exception:
            return {}

    @staticmethod
    def _free() -> None:
        try:
            import gc

            import torch

            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except ImportError:
            pass
